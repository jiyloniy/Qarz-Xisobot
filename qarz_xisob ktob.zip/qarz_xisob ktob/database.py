
import os
import django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'config.settings')

django.setup()


from api.models import User, Debt, Payment
# create user 20

for i in range(20):
    user = User.objects.create(name=f'Name {i}', second_name=f'Second Name {i}', phone=f'+998 99 999 99 9{i}')
    Debt.objects.create(user=user, amount=1000)
    Payment.objects.create(user=user, amount=500)
    Payment.objects.create(user=user, amount=500)
    print(f'User {i} created')

print('All users created')