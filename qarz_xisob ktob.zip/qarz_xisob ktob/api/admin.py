from django.contrib import admin

# Register your models here.
from api.models import User, Debt, Payment,Allpays

admin.site.register(User)
admin.site.register(Debt)
admin.site.register(Payment)
admin.site.register(Allpays)

