from django.db.models import Sum, Case, When, OuterRef, Subquery, F, Value
from django.db.models.functions import JSONObject
from rest_framework import viewsets
from rest_framework.response import Response
from drf_yasg.utils import swagger_auto_schema
from api.models import User, Allpays
from api.serializers import UserSerializer, AllpaysSerializer
from rest_framework import viewsets
from rest_framework.response import Response
from django.db import models
from django.db.models import Sum, Case, When, OuterRef, Subquery, F, Value
from django.db.models.functions import JSONObject
from rest_framework import viewsets
from rest_framework.response import Response
from drf_yasg.utils import swagger_auto_schema
from api.models import User, Allpays
from api.serializers import UserSerializer, AllpaysSerializer
from django.db.models import Sum, Case, When, OuterRef, Subquery, F, Value
from django.db.models.functions import JSONObject
from rest_framework import viewsets
from rest_framework.response import Response
from drf_yasg.utils import swagger_auto_schema
from api.models import User, Allpays
from api.serializers import UserSerializer, AllpaysSerializer
from django.db.models import Sum, Case, When, F, Subquery, OuterRef, Value, IntegerField, FloatField, DateTimeField, BooleanField
from django.db.models.functions import JSONObject
from rest_framework import viewsets
from .models import User, Allpays
from .serializers import UserSerializer

class UserViewSet3(viewsets.ModelViewSet):
    queryset = User.objects.all()
    serializer_class = UserSerializer

    def list(self, request, *args, **kwargs):
        users = User.objects.annotate(
            total_debts=Sum(Case(When(allpays__is_qarz=True, then='allpays__amount'))),
            total_payments=Sum(Case(When(allpays__is_qarz=False, then='allpays__amount')))
        ).prefetch_related('allpays')

        all_debts = users.aggregate(Sum('total_debts'))['total_debts__sum'] or 0
        all_payments = users.aggregate(Sum('total_payments'))['total_payments__sum'] or 0

        user_data = users.annotate(
            qarzlar=Subquery(
                Allpays.objects.filter(user=OuterRef('pk'))
                .order_by('-date')
                .annotate(
                    qarz=JSONObject(
                        qarz_id=Value('id', output_field=IntegerField()),
                        amount=Value('amount', output_field=FloatField()),
                        date=Value('date', output_field=DateTimeField()),
                        is_qarz=Value('is_qarz', output_field=BooleanField()),
                    )
                )
                .values('qarz')
            ),
            # remaining_debt=F('total_debts') - F('total_payments')
            remaining_debt=Case(
                When(total_debts__isnull=True, then=0),
                default=F('total_debts') - F('total_payments'),
                output_field=models.FloatField()
            )
        ).values(
            'id', 'name', 'second_name', 'phone', 'payment', 'debt',
            'total_debts', 'total_payments', 'remaining_debt', 'qarzlar'
        )

        return Response(user_data)