from django.shortcuts import render
from django.db.models import Sum, F
from rest_framework import viewsets
from rest_framework.response import Response
from rest_framework.decorators import action
from rest_framework import status
from api.models import User, Allpays
from api.serializers import UserSerializer, AllpaysSerializer
from drf_yasg.utils import swagger_auto_schema
from drf_yasg import openapi


class UserViewSet(viewsets.ModelViewSet):
    queryset = User.objects.all()
    serializer_class = UserSerializer

    @swagger_auto_schema(
        operation_description='Get all users',
        responses={200: UserSerializer(many=True)}
    )
    def list(self, request, *args, **kwargs):
        users = User.objects.all()
        data = []
        for user in users:
            all_debts = Allpays.objects.filter(user=user, is_qarz=True)
            all_payments = Allpays.objects.filter(user=user, is_qarz=False)
            user_all_debts_amount = all_debts.aggregate(Sum('amount'))['amount__sum'] or 0
            user_all_payments_amount = all_payments.aggregate(Sum('amount'))['amount__sum'] or 0
            qolgan_qarz = user_all_debts_amount - user_all_payments_amount
            qolgan_qarz = abs(qolgan_qarz)
            jami = all_debts.union(all_payments).order_by('-date')

            data.append({
                'user': UserSerializer(user).data,
                'qarzlar': AllpaysSerializer(jami, many=True).data,
                'jami_olingan_qarzlar': user_all_debts_amount,
                'jami_tulangan_qarzlar': user_all_payments_amount,
                'qolgan_qarz': qolgan_qarz,
            })

        all_debts = Allpays.objects.filter(is_qarz=True).aggregate(Sum('amount'))['amount__sum'] or 0
        all_payments = Allpays.objects.filter(is_qarz=False).aggregate(Sum('amount'))['amount__sum'] or 0

        return Response(
            data={
                'users': data[::-1],
                'jami_qarzlar': all_debts,
                'jami_tulangan_qarzlar': all_payments,
                'jami_qolgan_qarzlar': all_debts - all_payments,
            }
        )
class AllpayViewSet(viewsets.ModelViewSet):
    queryset = Allpays.objects.all()
    serializer_class = AllpaysSerializer




