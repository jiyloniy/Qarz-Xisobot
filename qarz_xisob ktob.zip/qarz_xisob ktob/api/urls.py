from django.urls import path
from api.views import DebtViewSet,PaymentViewSet,ReportViewSet
from api.views2 import UserViewSet,AllpayViewSet
from api.views3 import UserViewSet3
from rest_framework.routers import DefaultRouter

router = DefaultRouter()
router.register(r'users', UserViewSet, basename='user')
router.register(r'debts', AllpayViewSet, basename='debt')
router.register(r'users3', UserViewSet3, basename='payment')

urlpatterns = router.urls
