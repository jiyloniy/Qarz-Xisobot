from django.shortcuts import render
from django.db.models import Sum, F
from rest_framework import viewsets
from rest_framework.response import Response
from rest_framework.decorators import action
from rest_framework import status
from api.models import User, Debt, Payment, Allpays
from api.serializers import UserSerializer, DebtSerializer, PaymentSerializer,DebtSerializer2,PaymentSerializer2,AllpaysSerializer
from drf_yasg.utils import swagger_auto_schema
from drf_yasg import openapi

class UserViewSet(viewsets.ModelViewSet):
    queryset = User.objects.all()
    serializer_class = UserSerializer

    # all information about user
    @swagger_auto_schema(responses={200: UserSerializer()})
    @action(detail=True, methods=['get'])
    def info(self, request, pk=None):
        user = self.get_object()
        user_all_payments = Payment.objects.filter(user=user)
        user_all_debts = Debt.objects.filter(user=user)
        user_all_debts_amount = Debt.objects.filter(user=user).aggregate(Sum('amount'))
        user_all_payments_amount = Payment.objects.filter(user=user).aggregate(Sum('amount'))
        if user_all_debts_amount['amount__sum'] is not None:
            qolgan_qarz = user_all_debts_amount['amount__sum'] - user_all_payments_amount['amount__sum']
            qolgan_qarz = abs(qolgan_qarz)
        else:
            qolgan_qarz = 0

        return Response({
            'user': UserSerializer(user).data,
            'qarzlar': DebtSerializer2(user_all_debts, many=True).data,
            'qaytarilgan_qarzlar': PaymentSerializer(user_all_payments, many=True).data,
            'jami_olingan_qarzlar': user_all_debts_amount,
            'jami_tulangan_qarzlar': user_all_payments_amount,
            'qolgan_qarz': qolgan_qarz,

        })
   
    def list(self, request, *args, **kwargs):
        users = User.objects.all()
        data = []
        for user in users:
            all_debts = Debt.objects.filter(user=user)
            all_payments = Payment.objects.filter(user=user)
            user_all_debts_amount = Debt.objects.filter(user=user).aggregate(Sum('amount'))
            user_all_payments_amount = Payment.objects.filter(user=user).aggregate(Sum('amount'))
            if user_all_debts_amount['amount__sum'] is not None:
                qolgan_qarz = user_all_debts_amount['amount__sum'] - user_all_payments_amount['amount__sum']
                qolgan_qarz = abs(qolgan_qarz)
            else:
                qolgan_qarz = 0
            
            data.append({
                'user': UserSerializer(user).data,
                'qarzlar': DebtSerializer2(all_debts, many=True).data,
                'qaytarilgan_qarzlar': PaymentSerializer2(all_payments, many=True).data,
                'jami_olingan_qarzlar': user_all_debts_amount,
                'jami_tulangan_qarzlar': user_all_payments_amount,
                'qolgan_qarz': qolgan_qarz,
            })
        all_debts = Debt.objects.aggregate(Sum('amount'))
        all_payments = Payment.objects.aggregate(Sum('amount'))
        return Response(
            data={
                'users': data,
                'jami_qarzlar': all_debts,
                'jami_tulangan_qarzlar': all_payments,
                'jami_qolgan_qarzlar': all_debts['amount__sum'] - all_payments['amount__sum'],
            }
        )
        
        
   
class DebtViewSet(viewsets.ModelViewSet):
    queryset = Debt.objects.all()
    serializer_class = DebtSerializer

    def list(self, request, *args, **kwargs):
        users = User.objects.all()
        data = []
        for user in users:
            all_debts = Debt.objects.filter(user=user)
            data.append({
                'user': UserSerializer(user).data['name'],
                'qarzlar': DebtSerializer2(all_debts, many=True).data,
            })
        # jami qarzlar ni qo'shish
        all_debts = Debt.objects.aggregate(Sum('amount'))
        return Response(
            data={
                'users': data,
                'jami_qarzlar': all_debts,
            }
        )
    @swagger_auto_schema(responses={200: UserSerializer()})
    @action(detail=True, methods=['get'])
    def info(self, request, pk=None):
        user = User.objects.get(pk=pk)
        
        user_all_debts = Debt.objects.filter(user=user)
        user_all_debts_amount = Debt.objects.filter(user=user).aggregate(Sum('amount'))
        

        return Response({
            'user': UserSerializer(user).data['name'],
            'qarzlar': DebtSerializer2(user_all_debts, many=True).data,
           
            'jami_olingan_qarzlar': user_all_debts_amount,
           

        })


class PaymentViewSet(viewsets.ModelViewSet):
    queryset = Payment.objects.all()
    serializer_class = PaymentSerializer

    def create(self, request, *args, **kwargs):
        user = User.objects.get(pk=request.data['user'])
        user_all_debts_amount = Debt.objects.filter(user=user).aggregate(Sum('amount'))
        pay = float(request.data['amount'])
        if user_all_debts_amount['amount__sum'] < pay:
            return Response({'error': 'Qarzdan ortiq pul kiritildi'}, status=status.HTTP_400_BAD_REQUEST)
        
        return super().create(request, *args, **kwargs)
    
    def list(self, request, *args, **kwargs):
        users = User.objects.all()
        data = []
        for user in users:
            all_payments = Payment.objects.filter(user=user)
            data.append({
                'user': UserSerializer(user).data['name'],
                'qaytarilgan_qarzlar': PaymentSerializer(all_payments, many=True).data,
            })
        # jami qarzlar ni qo'shish

        all_payments = Payment.objects.aggregate(Sum('amount'))
        return Response(
            data={
                'users': data,
                'jami_qarzlar': all_payments,
            }
        )
    # user info
    @swagger_auto_schema(responses={200: UserSerializer()})
    @action(detail=True, methods=['get'])
    def info(self, request, pk=None):
        user = User.objects.filter(id=pk).first
        
        user_all_payments = Payment.objects.filter(user=user)

        user_all_payments_amount = Payment.objects.filter(user=user).aggregate(Sum('amount'))

        return Response({
            'user': UserSerializer(user).data['name'],
            
            'qaytarilgan_qarzlar': PaymentSerializer(user_all_payments, many=True).data,
            
            'jami_tulangan_qarzlar': user_all_payments_amount,
            

        })



from io import BytesIO
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import letter

from django.http import HttpResponse
from django.db.models import Sum
"""
olgan qarzlar ro'yhati va uni oldida olgan kuni qaytragan qarzlar ro'yhati va qaytargan kuni va qarzlar jami va qaytrarilgan jami va qolgan qarzlarni chiqarish kerak jadval ko'rinishida va chiziqlar bilan chizish kerak"""
from io import BytesIO
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import letter

from django.http import HttpResponse
from django.db.models import Sum
from io import BytesIO
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import letter

from django.http import HttpResponse
from django.db.models import Sum
global inch 
inch = 48
class ReportViewSet(viewsets.ViewSet):
    # @swagger_auto_schema(responses={200: UserSerializer()})
    @action(detail=False, methods=['get'])
    def report(self, request):
        def create_pdf(users, response):
            buffer = BytesIO()
            p = canvas.Canvas(buffer, pagesize=letter)
            p.setFont('Helvetica', 7)  # Font size o'zgardi

            # Sarlavha
            p.drawString(1 * inch, 10.5 * inch, 'Qarzdorlar hisoboti')

            y = 10 * inch
            for user in users:
                all_debts = Debt.objects.filter(user=user).order_by('date')
                all_payments = Payment.objects.filter(user=user).order_by('date')
                user_all_debts_amount = Debt.objects.filter(user=user).aggregate(Sum('amount'))
                user_all_payments_amount = Payment.objects.filter(user=user).aggregate(Sum('amount'))
                if user_all_debts_amount['amount__sum'] is not None:
                    qolgan_qarz = user_all_debts_amount['amount__sum'] - user_all_payments_amount['amount__sum']
                    qolgan_qarz = abs(qolgan_qarz)
                else:
                    qolgan_qarz = 0

                # Jadval sarlavhasi
                p.drawString(1 * inch, y, f"{user.name} {user.second_name}")
                y -= 0.4 * inch  # Qator oraliq masofasi o'zgardi

                # Jadval ustunlari sarlavhalari
                x = 1 * inch
                p.drawString(x, y, 'Qarzlar')
                p.drawString(x + 1.5 * inch, y, 'Olgan sana')  # Ustun kengligi o'zgardi
                p.drawString(x + 3.5 * inch, y, 'To\'langan qarzlar')  # Ustun kengligi o'zgardi
                p.drawString(x + 5.5 * inch, y, 'To\'langan sana')  # Ustun kengligi o'zgardi
                p.drawString(x + 7.5 * inch, y, 'Jami olingan')  # Ustun kengligi o'zgardi
                p.drawString(x + 9 * inch, y, 'Jami to\'langan')  # Ustun kengligi o'zgardi
                p.drawString(x + 10.5 * inch, y, 'Qolgan qarz')  # Ustun kengligi o'zgardi
                y -= 0.4 * inch  # Qator oraliq masofasi o'zgardi

                # Jadval chegaralari
                p.line(x, y, x + 10.5 * inch, y)  # Jadval kengligi o'zgardi
                p.line(x, y + 0.4 * inch, x, y - (len(all_debts) + len(all_payments) + 1) * 0.4 * inch)
                p.line(x + 1.5 * inch, y + 0.4 * inch, x + 1.5 * inch, y - (len(all_debts) + 1) * 0.4 * inch)
                p.line(x + 3.5 * inch, y + 0.4 * inch, x + 3.5 * inch, y - (len(all_payments) + 1) * 0.4 * inch)
                p.line(x + 5.5 * inch, y + 0.4 * inch, x + 5.5 * inch, y - (len(all_payments) + 1) * 0.4 * inch)
                p.line(x + 7.5 * inch, y + 0.4 * inch, x + 7.5 * inch, y - 1 * 0.4 * inch)
                p.line(x + 9 * inch, y + 0.4 * inch, x + 9 * inch, y - 1 * 0.4 * inch)
                p.line(x + 10.5 * inch, y + 0.4 * inch, x + 10.5 * inch, y - 1 * 0.4 * inch)
                p.line(x, y - (len(all_debts) + len(all_payments) + 1) * 0.4 * inch, x + 10.5 * inch, y - (len(all_debts) + len(all_payments) + 1) * 0.4 * inch)

                # Qarzlar ro'yxati
                for debt in all_debts:
                    
                    p.drawString(x, y, str(debt.amount))
                    p.drawString(x + 1.5 * inch, y, str(debt.date.date()))
                    y -= 0.4 * inch

                # To'langan qarzlar ro'yxati
                for payment in all_payments:
                    p.drawString(x + 3.5 * inch, y, str(payment.amount))
                    p.drawString(x + 5.5 * inch, y, str(payment.date.date()))
                    y -= 0.4 * inch
                    

                # Jami qarzlar, to'langan qarzlar va qolgan qarz
                p.drawString(x + 7.5 * inch, y, str(user_all_debts_amount['amount__sum']))
                p.drawString(x + 9 * inch, y, str(user_all_payments_amount['amount__sum']))
                p.drawString(x + 10.5 * inch, y, str(qolgan_qarz))
                y -= 1 * inch

                if y < 1 * inch:
                    p.showPage()
                    y = 10 * inch
            # umumiy hisob kitob qismi
            p.drawString(1 * inch, y, 'Umumiy hisob kitob')
            y -= 0.4 * inch
            # jami do'kon qarzi
            all_debts = Debt.objects.all()
            all_debts_amount = Debt.objects.aggregate(Sum('amount'))
            p.drawString(1 * inch, y, 'Jami qarzi')
            p.drawString(5 * inch, y, str(all_debts_amount['amount__sum']))
            y -= 0.4 * inch
            # jami to'langan qarzlar
            all_payments = Payment.objects.all()
            all_payments_amount = Payment.objects.aggregate(Sum('amount'))
            p.drawString(1 * inch, y, 'Jami to\'langan qarzlar')
            p.drawString(5 * inch, y, str(all_payments_amount['amount__sum']))
            y -= 0.4 * inch
            # jami qolgan qarzlar
            p.drawString(1 * inch, y, 'Jami qolgan qarzlar')
            p.drawString(5 * inch, y, str(all_debts_amount['amount__sum'] - all_payments_amount['amount__sum']))
            y -= 0.4 * inch

            


            p.showPage()
            p.save()
            pdf = buffer.getvalue()
            buffer.close()
            response.write(pdf)
            return response

        users = User.objects.all()

        response = HttpResponse(content_type='application/pdf')
        response['Content-Disposition'] = 'attachment; filename="report.pdf"'

        return create_pdf(users, response)
    
    # report for one user
    @action(detail=True, methods=['get'])
    def user_report(self, request, pk=None):
        def create_pdf(user, response):
            buffer = BytesIO()
            p = canvas.Canvas(buffer, pagesize=letter)
            p.setFont('Helvetica', 7)  # Font size o'zgardi

            # Sarlavha
            p.drawString(1 * inch, 10.5 * inch, f"{user.name} {user.second_name} hisoboti")

            all_debts = Debt.objects.filter(user=user).order_by('date')
            all_payments = Payment.objects.filter(user=user).order_by('date')
            user_all_debts_amount = Debt.objects.filter(user=user).aggregate(Sum('amount'))
            user_all_payments_amount = Payment.objects.filter(user=user).aggregate(Sum('amount'))
            if user_all_debts_amount['amount__sum'] is not None:
                qolgan_qarz = user_all_debts_amount['amount__sum'] - user_all_payments_amount['amount__sum']
                qolgan_qarz = abs(qolgan_qarz)
            else:
                qolgan_qarz = 0

            y = 10 * inch
            # Jadval sarlavhasi
            p.drawString(1 * inch, y, f"{user.name} {user.second_name}")
            y -= 0.4 * inch  # Qator oraliq masofasi o'zgardi

            # Jadval ustunlari sarlavhalari
            x = 1 * inch
            p.drawString(x, y, 'Qarzlar')
            p.drawString(x + 1.5 * inch, y, 'Olgan sana')  # Ustun kengligi o'zgardi
            p.drawString(x + 3.5 * inch, y, 'To\'langan qarzlar')  # Ustun kengligi o'zgardi
            p.drawString(x + 5.5 * inch, y, 'To\'langan sana')  # Ustun kengligi o'zgardi
            p.drawString(x + 7.5 * inch, y, 'Jami olingan')  # Ustun kengligi o'zgardi
            p.drawString(x + 9 * inch, y, 'Jami to\'langan')  # Ustun kengligi o'zgardi
            p.drawString(x + 10.5 * inch, y, 'Qolgan qarz')  # Ustun kengligi o'zgardi
            y -= 0.4 * inch

            # Jadval chegaralari
            p.line(x, y, x + 10.5 * inch, y)
            p.line(x, y + 0.4 * inch, x, y - (len(all_debts) + len(all_payments) + 1) * 0.4 * inch)
            p.line(x + 1.5 * inch, y + 0.4 * inch, x + 1.5 * inch, y - (len(all_debts) + 1) * 0.4 * inch)
            p.line(x + 3.5 * inch, y + 0.4 * inch, x + 3.5 * inch, y - (len(all_payments) + 1) * 0.4 * inch)
            p.line(x + 5.5 * inch, y + 0.4 * inch, x + 5.5 * inch, y - (len(all_payments) + 1) * 0.4 * inch)
            p.line(x + 7.5 * inch, y + 0.4 * inch, x + 7.5 * inch, y - 1 * 0.4 * inch)
            p.line(x + 9 * inch, y + 0.4 * inch, x + 9 * inch, y - 1 * 0.4 * inch)
            p.line(x + 10.5 * inch, y + 0.4 * inch, x + 10.5 * inch, y - 1 * 0.4 * inch)
            
            p.line(x, y - (len(all_debts) + len(all_payments) + 1) * 0.4 * inch, x + 10.5 * inch, y - (len(all_debts) + len(all_payments) + 1) * 0.4 * inch)
            
            # Qarzlar ro'yxati
            for debt in all_debts:
                p.drawString(x+1, y-8, str(debt.amount))
                p.drawString(x + 1.6 * inch, y-8, str(debt.date.date()))
                y -= 0.4 * inch

            # To'langan qarzlar ro'yxati

            for payment in all_payments:
                p.drawString(x + 3.6 * inch, y+30, str(payment.amount))
                p.drawString(x + 5.6 * inch, y+30, str(payment.date.date()))
                y -= 0.4 * inch

            # Jami qarzlar, to'langan qarzlar va qolgan qarz
            p.drawString(x + 7.5 * inch, y, str(user_all_debts_amount['amount__sum']))
            p.drawString(x + 9 * inch, y, str(user_all_payments_amount['amount__sum']))
            p.drawString(x + 10.5 * inch, y, str(qolgan_qarz))
            y -= 1 * inch

            # umumiy hisob kitob qismi
            p.drawString(1 * inch, y, 'Umumiy hisob kitob')
            y -= 0.4 * inch
            # jami do'kon qarzi
            
            all_debts = Debt.objects.filter(user=user)
            all_debts_amount = Debt.objects.filter(user=user).aggregate(Sum('amount'))

            p.drawString(1 * inch, y, 'Jami qarzi')
            p.drawString(5 * inch, y, str(all_debts_amount['amount__sum']))
            y -= 0.4 * inch
            # jami to'langan qarzlar
            all_payments = Payment.objects.filter(user=user)
            all_payments_amount = Payment.objects.filter(user=user).aggregate(Sum('amount'))
            p.drawString(1 * inch, y, 'Jami to\'langan qarzlar')
            p.drawString(5 * inch, y, str(all_payments_amount['amount__sum']))
            y -= 0.4 * inch
            # jami qolgan qarzlar
            p.drawString(1 * inch, y, 'Jami qolgan qarzlar')
            p.drawString(5 * inch, y, str(all_debts_amount['amount__sum'] - all_payments_amount['amount__sum']))
            y -= 0.4 * inch

            p.showPage()
            p.save()
            pdf = buffer.getvalue()
            buffer.close()
            response.write(pdf)
            return response
        
        user = User.objects.get(pk=pk)

        response = HttpResponse(content_type='application/pdf')
        response['Content-Disposition'] = f'attachment; filename="{user.name}_{user.second_name}_report.pdf"'
        return create_pdf(user, response)
    