from api.models import User,Debt,Payment,Allpays
from rest_framework import serializers

class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = '__all__'


class DebtSerializer2(serializers.ModelSerializer):
    class Meta:
        model = Debt
        fields = ['amount','date','id']

class PaymentSerializer2(serializers.ModelSerializer):
    class Meta:
        model = Payment
        fields = ['amount','date','id']

class DebtSerializer(serializers.ModelSerializer):
    class Meta:
        model = Debt
        fields = '__all__'

class PaymentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Payment
        fields = '__all__'


class PaymentSerializer1(serializers.ModelSerializer):
    class Meta:
        model = Payment
        fields = '__all__'

class AllpaysSerializer(serializers.ModelSerializer):
    class Meta:
        model = Allpays
        fields = '__all__'

